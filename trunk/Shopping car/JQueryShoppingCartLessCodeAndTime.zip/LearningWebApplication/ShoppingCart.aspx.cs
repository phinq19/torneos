﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LearningWebApplication
{
    public partial class ShoppingCart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            var products = GetProducts();

            dlProducts.DataSource = products;
            dlProducts.DataBind(); 
        }

        private object GetProducts()
        {
            var products = new List<Product>
                               {
                                   new Product()
                                       {Code = "ASD123", Name = "Product 1", Description = "Product 1", Price = 12.34},
                                   new Product() {Code = "BBB123", Name = "Product 2", Description = "Product 2", Price=15}
                                   ,
                                   new Product() {Code = "CCC123", Name = "Product 3", Description = "Product 3", Price=20}
                                   ,
                                   new Product() {Code = "DDD123", Name = "Product 4", Description = "Product 4", Price=12.99},
                                   new Product() {Code = "EEE123", Name = "Product 5", Description = "Product 5", Price=14.95}
                               };


            return products;
        }
    }
}